<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Hi there!  I\'m just a plugin, not much I can do when called directly.' );
}

/**
 * Gallery shortcode handler.
 * do nothing and leave rendering of the gallery completely to the theme
 */
function youxi_gallery_shortcode_cb( $atts, $content, $tag ) {
	ob_start();
	$args = func_get_args();
	do_action_ref_array( 'youxi_gallery_shortcode_output', $args );
	return ob_get_clean();
}

/**
 * Gallery shortcode tag
 */
function youxi_gallery_shortcode_tag() {
	return apply_filters( 'youxi_gallery_shortcode_tag', 'gallery_entries' );
}

/**
 * Register shortcode
 */
function youxi_gallery_shortcode_register( $manager ) {

	if( ! apply_filters( 'youxi_gallery_register_shortcode', true ) ) {
		return;
	}

	/* Add a hook to make registering another shortcode category possible */
	do_action( 'youxi_gallery_shortcode_register' );

	/********************************************************************************
	 * Gallery shortcode
	 ********************************************************************************/
	$manager->add_shortcode( youxi_gallery_shortcode_tag(), array(
		'label' => apply_filters( 'youxi_gallery_shortcode_label', __( 'Gallery Entries', 'youxi' ) ), 
		'category' => apply_filters( 'youxi_gallery_shortcode_category', 'content' ), 
		'priority' => 55, 
		'icon' => 'fa fa-photo', 
		'atts' => apply_filters( 'youxi_gallery_shortcode_atts', array() ), 
		'callback' => 'youxi_gallery_shortcode_cb'
	) );
}
add_action( 'youxi_shortcode_register', 'youxi_gallery_shortcode_register' );
