<?php
/*
Plugin Name: Youxi Gallery
Plugin URI: http://www.themeforest.net/user/nagaemas
Description: This plugin registers a gallery custom post type and optionally registers a shortcode to ease displaying the galleries. Through the filters and actions provided, you can freely add, modify or remove any post type argument/field.
Version: 1.0
Author: YouxiThemes
Author URI: http://www.themeforest.net/user/nagaemas
License: Envato Marketplace Licence

Changelog:
1.0
- Initial release
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Hi there!  I\'m just a plugin, not much I can do when called directly.' );
}

function youxi_gallery_plugins_loaded() {

	if( ! defined( 'YOUXI_CORE_VERSION' ) ) {

		if( ! class_exists( 'Youxi_Admin_Notice' ) ) {
			require( plugin_dir_path( __FILE__ ) . 'class-admin-notice.php' );
		}
		Youxi_Admin_Notice::instance()->add_error( __FILE__, __( 'This plugin requires you to install and activate the Youxi Core plugin.', 'youxi' ) );

		return;

	} else if( version_compare( YOUXI_CORE_VERSION, '1.4', '<' ) ) {

		if( ! class_exists( 'Youxi_Admin_Notice' ) ) {
			require( plugin_dir_path( __FILE__ ) . 'class-admin-notice.php' );
		}
		Youxi_Admin_Notice::instance()->add_error( __FILE__, __( 'This plugin requires at least Youxi Core 1.4 to function properly.', 'youxi' ) );

		return;
	}

	define( 'YOUXI_GALLERY_VERSION', '1.0' );

	define( 'YOUXI_GALLERY_DIR', plugin_dir_path( __FILE__ ) );

	define( 'YOUXI_GALLERY_URL', plugin_dir_url( __FILE__ ) );

	define( 'YOUXI_GALLERY_LANG_DIR', dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

	/* Load Language File */
	load_plugin_textdomain( 'youxi', false, YOUXI_GALLERY_LANG_DIR );

	require_once( YOUXI_GALLERY_DIR . 'class-gallery.php' );

	require_once( YOUXI_GALLERY_DIR . 'gallery-shortcode.php' );
}
add_action( 'plugins_loaded', 'youxi_gallery_plugins_loaded' );
